<div class="profile_nav">
          <ul>
            <li><a href="profile.php">Pengaturan Profil</a></li>
              <li><a href="update-password.php">Perbarui Kata Sandi</a></li>
            <li><a href="my-booking.php">Pemesanan Saya</a></li>
            <li><a href="post-testimonial.php">Posting Testimonial</a></li>
               <li><a href="my-testimonials.php">Testimonial Saya</a></li>
            <li><a href="logout.php">Keluar</a></li>
          </ul>
        </div>
      </div>