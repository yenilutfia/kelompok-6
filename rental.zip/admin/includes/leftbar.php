<nav class="ts-sidebar">
	<ul class="ts-sidebar-menu">
	<li class="ts-label">Main</li>
	<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>

<li><a href="#"><i class="fa fa-files-o"></i> Merek</a>
	<ul>
	<li><a href="create-brand.php">Buat Merek</a></li>
	<li><a href="manage-brands.php">Kelola Merek</a></li>
	</ul>
	</li>

<li><a href="#"><i class="fa fa-sitemap"></i> Motor</a>
	<ul>
	<li><a href="post-avehical.php">Post Motor</a></li>
	<li><a href="manage-vehicles.php">Kelola Motor</a></li>
	</ul>
	</li>
	
<li><a href="manage-bookings.php"><i class="fa fa-users"></i> Kelola Pemesanan</a></li>

<li><a href="testimonials.php"><i class="fa fa-table"></i> Kelola Testimonial</a></li>

<li><a href="manage-contactusquery.php"><i class="fa fa-desktop"></i> Kelola Pertanyaan</a></li>

<li><a href="reg-users.php"><i class="fa fa-users"></i> Pengguna Terdaftar</a></li>

<li><a href="manage-pages.php"><i class="fa fa-files-o"></i> Kelola Halaman</a></li>
			
<li><a href="manage-subscribers.php"><i class="fa fa-table"></i> Kelola Pelanggan</a></li>

	</ul>
</nav>